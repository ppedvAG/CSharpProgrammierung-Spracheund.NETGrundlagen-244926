﻿#region Variablen

// Kommentare
/*
 mehrzeiliger Kommentarblock
 
*/

//Hallo


// hotkey kommentieren = [Strg]+[k] + [Strg]+[c]
// hotkey auskommentieren = [Strg]+[k] + [Strg]+[u]

// Variablen
int Zahl = 10;

Console.WriteLine(Zahl);  // Kurzschreibweise cw + Tab



int Alter;
Alter = 20;
int DoppeltesAlter = Alter * 2;
string Stadt = "Berlin";
Console.WriteLine(DoppeltesAlter);
Console.WriteLine(Stadt);

// Datentypen
// Ganzzahl
int i = 23;
long l = 23;
short s = 23;
byte b = 23;

// Gleitkomma
// double, float, decimal
double d = 23.65;

float f = 23.65f;   // jede Kommazahl ist ein Double. Mit f am Ende kann eine Konvertierung durchgeführt werden.

decimal dd = 23.65m; // Mit dem M-Suffix umwandeln

string str = "Hallo World"; // doppelte Hochkomma	kein Speihcerproblem, bis 4GB möglich
char c = 'a';	// Char in einfachen Hochkomma

Console.WriteLine(str);

bool bWahr = true;
bool bFalsch = false;


#endregion

#region Strings

int alterVonMax = 20;
string Ausgabe;


Console.WriteLine("Hallo " + f);

//$-Prefix (String-Interpolation
Console.WriteLine($"Der Double ist {d}, der Float-Wert ist {f}, der Float-Wert * 5 ist {f*5}");

// Escape Sequenzen: Untippbare Zeichenin String einbetten
Console.WriteLine("Zeilenumbruch \n Zeilenumbruch");
Console.WriteLine("Tab \t Tab");



// @	Escape Sequencen







#endregion

#region Eingabe

// Console.ReadLine(); waret auf die Eingabe und speichert in die Übergabevariable
Console.WriteLine("\n\n");
Console.WriteLine("Gebe bitte einen String ein:\n");
string eingabe = Console.ReadLine();
Console.WriteLine($"Du hast {eingabe} eingegeben");

// Console.ReadKey() wartet auf eine Tasteneingabe
//ConsoleKeyInfo taste = Console.ReadKey();						ConsoleKeyInfo => Struktur, Struktur sind eine Art Objekte
//Console.WriteLine(taste.Key);

#endregion

#region Konvertierung Typecast
string usereingabe = Console.ReadLine();
// String zu Zahl
int konvertierung = int.Parse(usereingabe);

Console.WriteLine($"Deine Zahl mal 2 ist: {konvertierung * 2}!");

// Zahl zu string
Console.WriteLine(konvertierung.ToString());

// Zahl zu Zahl: Typecast, cast, 



#endregion


#region Arithmetik
int zahl1 = 7;
int zahl2 = 3;

zahl1 += zahl2;
Console.WriteLine(Zahl);

int summe = zahl1 * zahl2;
Console.WriteLine(summe);

#endregion












