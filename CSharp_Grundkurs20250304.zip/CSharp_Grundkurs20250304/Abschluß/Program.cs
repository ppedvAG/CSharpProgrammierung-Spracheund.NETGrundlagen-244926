﻿
using System.Reflection;

internal class Program
{
	static void Main(string[] args)
	{
		List<Auto> autos = new List<Auto>()
		{
		new Auto("Audi", "A6", 2022, 55000.01, 5),
		new Auto("Audi", "A1", 2015, 15000.01, 3),
		new Auto("Audi", "A3", 2019, 25000.01, 5),
		new Auto("Audi", "A7", 2025, 101000.01, 3),
		new Auto("VW", "Golf", 2023, 40000.01, 5),
		new Auto("VW", "Polo", 2025, 23000.01, 3),
		new Auto("VW", "TRoc", 2020, 31000.01, 5),
		new Auto("BMW", "320i", 2015, 11000.02, 5),
		new Auto("BMW", "320xd", 2019, 31000.01, 5),
		new Auto("BMW", "440", 2022, 45000.55, 2)
		};

		Auto a1 = new Auto("Ford", "Cmax", 2022, 35000.01, 5);
		Auto a2 = new Auto("Ford", "Smax", 2022, 45000.01, 5);


		List<Motorrad> motorrads = new List<Motorrad>()
															{
													new Motorrad("BMW", "C1", 2012, 3000, false),
													new Motorrad("Harley Davidson", "VRod", 2015, 25000, false),
													new Motorrad("Harley Davidson", "Sportster", 2025, 19000, false),
													new Motorrad("Honda", "CBF", 2015, 12000.55, false),
													new Motorrad("Honda", "Goldwing", 2017, 18000, true)
												};

		Fuhrpark fuhrpark = new Fuhrpark();

		fuhrpark.FahrzeugeHinzufuegen(new Fahrzeug[] {a1, a2});

		foreach (var item in autos)
		{
			fuhrpark.FahrzeugeHinzufuegen(new Fahrzeug[] {item});
		}

		foreach (var item in motorrads)
		{
			fuhrpark.FahrzeugeHinzufuegen(new Fahrzeug[] { item });
		}

		fuhrpark.AlleFahrzeugeAnzeigen();
		fuhrpark.FahrzeugeFilternNachPreis(30000);
		fuhrpark.FahrzeugeSortiertNachBaujahr();




        Console.WriteLine("\nAuto steuern");
		autos[1].Stoppen();
		autos[1].Starten();
		autos[1].Starten();
		autos[1].Stoppen();

		Console.WriteLine("\nMotorrad steuern");
		motorrads[1].Stoppen();
		motorrads[1].Starten();
		motorrads[1].Starten();
		motorrads[1].Stoppen();




	}
}





public class Fahrzeug
{
	public string Marke { get; set; }
	public string Modell { get; set; }
	public int Baujahr { get; set; }
	public double Preis { get; set; }

	public virtual string AnzeigeDetails()
	{ 
		string txt = $"Marke: {Marke}, Modell: {Modell}, Baujahr: {Baujahr}, Preis: {Preis}. ";
		return txt;
	}

	public Fahrzeug(string marke, string modell, int baujahr, double preis)
	{
		Marke = marke;
		Modell = modell;
		Baujahr = baujahr;
		Preis = preis;
	}
}

public class Auto : Fahrzeug, IFahrzeugAktionen
{

	public string Marke { get; set; }
	public string Modell { get; set; }
	public int Baujahr { get; set; }
	public double Preis { get; set; }

	internal int TuerAnz { get; set; }

	public override string AnzeigeDetails()
	{
		string txt = base.AnzeigeDetails();
		txt = txt + $"Das Auto hat {TuerAnz} Türen. ";
		return txt;
	}

	public	bool MotorLauft { get; set; }

	public bool Starten()
	{
		if (MotorLauft)
			Console.WriteLine("Der Motor des Autos läuft bereits");
		else
		{ 
			MotorLauft = true;
            Console.WriteLine("Der Motor des Autos wurde gestartet");
		}
		return MotorLauft;
	}
	public bool Stoppen()
	{
		if (MotorLauft)
		{
			MotorLauft = false;
			Console.WriteLine("Der Motor des Autos wurde gestoppt");
		}
		else
			Console.WriteLine("Der Motor des Autos ist schon gestoppt");
		return MotorLauft;
	}

	public Auto(string marke, string modell, int baujahr, double preis, int tuerAnz) : base(marke, modell, baujahr, preis)
	{
		TuerAnz = tuerAnz;
		MotorLauft = false;
	}
}

public class Motorrad: Fahrzeug, IFahrzeugAktionen
{
		public string Marke { get; set; }
	public string Modell { get; set; }
	public int Baujahr { get; set; }
	public double Preis { get; set; }

	internal bool BeiwagenVorh { get; set; }

	public override string AnzeigeDetails()
	{
		string txt = base.AnzeigeDetails();
		if(BeiwagenVorh)
			txt = txt + $"Das Motorrad hat einen Beiwagen. ";
		else
			txt = txt + $"Das Motorrad hat keinen Beiwagen. ";
		return txt;
	}


	public bool MotorLauft { get; set; }

	public bool Starten()
	{
		if (MotorLauft)
			Console.WriteLine("Der Motor des Motorrads läuft bereits");
		else
		{
			MotorLauft = true;
			Console.WriteLine("Der Motor des Motorrads wurde gestartet");
		}
		return MotorLauft;
	}
	public bool Stoppen()
	{
		if (MotorLauft)
		{
			MotorLauft = false;
			Console.WriteLine("Der Motor des Motorrads wurde gestoppt");
		}
		else
			Console.WriteLine("Der Motor des Motorrads ist schon gestoppt");
		return MotorLauft;
	}

	public Motorrad(string marke, string modell, int baujahr, double preis, bool beiwagenVorh) : base(marke, modell, baujahr, preis)
	{
		BeiwagenVorh = beiwagenVorh;
		MotorLauft = false;
	}
}


public interface IFahrzeugAktionen
{
	bool MotorLauft { get; set; }
	bool Starten();
	bool Stoppen();
}


public class Fuhrpark
{
	List<Fahrzeug> fuhrparkList = new List<Fahrzeug>();

	public void FahrzeugeHinzufuegen(Fahrzeug[] neueFahrzeuge)
	{
		foreach (var item in neueFahrzeuge)
		{
			fuhrparkList.Add(item);
		}


		// Alternativ ganzen Bereich hinzufügen
////		fuhrparkList.AddRange(neueFahrzeuge);

	}

	public void AlleFahrzeugeAnzeigen()
	{
        Console.WriteLine("##### FUHRPARK-INFO #####");
		Console.WriteLine($"Der Fuhrpark hat {fuhrparkList.Count()} Fahrzeuge:");
		foreach (var item in fuhrparkList)
            Console.WriteLine(item.AnzeigeDetails());	
	}

	public void FahrzeugeFilternNachPreis(double maxPreis)
	{
		var sortiert = fuhrparkList.Where(e => e.Preis < maxPreis).OrderBy(e => e.Preis);                    // in eine gruppierte Datenstruktur ausgeben	

// Alternative		sortiert = sortiert.OrderBy(e => e.Preis);

        Console.WriteLine($"\nBis zu einem Preis von {maxPreis} EUR haben wir folgende {sortiert.Count()} Fahrzeuge:");

		foreach (var item in sortiert)
			Console.WriteLine(item.AnzeigeDetails());
	}

	public void FahrzeugeSortiertNachBaujahr()
	{
		var sortiert = fuhrparkList.OrderBy(e => e.Baujahr);

		Console.WriteLine($"\nUnsere {sortiert.Count()} Fahrzeuge sortiert nach Baujahr:");

		foreach (var item in sortiert)
			Console.WriteLine(item.AnzeigeDetails());
	}
}


