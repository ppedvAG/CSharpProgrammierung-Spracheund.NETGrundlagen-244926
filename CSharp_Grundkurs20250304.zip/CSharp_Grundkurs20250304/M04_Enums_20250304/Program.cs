﻿using System.Net;   // wird für Schleifen benötigt


#region Schleifen
// while
int a = 0;
int b = 10;

while (a<b)
{
    Console.WriteLine(a);
    a++;
}

do
{ 
    //
    break;          // verlässt Schleife, wird aber nicht empfohlen

} while (a<b);


// break => verlässt Schleife
// continue => Überspringt weiteren Code in der Schleife und sprint zum Anfang zurück

a = 0; 
while (a<b)
{
    a++;
    if (a % 2 == 0)
        continue;           // springt wieder nach oben             ! bei einzeiligen Befehlen kann auf {} verzichtet werden
    Console.WriteLine($"aktuelle Schleife: {a}");
}


// for-Schleife
for (int i = 0; i < 10; i++)
{


}

// Iterieren eines Arrays
int[] zahlen = [1,2,3,4,5,6];
for (int i = 0; i < zahlen.Length; i++)
{
    Console.WriteLine (zahlen[i]);
}

// foreach-Schleife
// ist der for-Schleife vorzuziehen
foreach (int element in zahlen)
{
    Console.WriteLine ($"foreach-Schleife {element}");
}
#endregion

#region Enum
// immer Integer

Wochentag wt = Wochentag.DI;
if (wt == Wochentag.DI)
    Console.WriteLine("Treffe Wochentag");

#endregion

#region switch

Wochentag t = Wochentag.FR;

switch (t)
{
    case Wochentag.MO:
    case Wochentag.DI:
        Console.WriteLine("Wochenanfang");
        break;

    case Wochentag.MI:
		Console.WriteLine("Wochenmitte");
		break;
	case Wochentag.DO:
	case Wochentag.FR:
		Console.WriteLine("Ende der Woche");
		break;

	default:
		Console.WriteLine("Wochenende");
        break;

}

// boolscher Switch
switch (t)
{
	case >= Wochentag.MO and <= Wochentag.FR:
		Console.WriteLine("Wochentag");
		break;

	case Wochentag.SA or Wochentag.SO:
		Console.WriteLine("Wochenende");
		break;

	default:
		Console.WriteLine("FATAL ERROR");
		break;
}

#endregion



#region Taschenrechner
double z1, z2;
Rechenarten i_ra;
Rechenarten[] ar_ra = Enum.GetValues<Rechenarten>();		// füllt komplettes Array mit allen Werten der Enum-Varianten

do
{
	Console.WriteLine("\n");
	Console.WriteLine("Taschenrechner");
	Console.WriteLine("\n");
	Console.WriteLine("Gib die erste Zahl ein: ");
	z1 = double.Parse(Console.ReadLine());

	Console.WriteLine("Gib die zweite Zahl ein: ");
	z2 = double.Parse(Console.ReadLine());


	// Anzeige der Rechenoperationen
	Console.WriteLine("Wähle eine Rechenart aus:");
	//foreach (var i in ar_ra)						funktioniert auch
	foreach (var i in Enum.GetValues<Rechenarten>())
	{
		Console.WriteLine($"{(int)i}: {i}");
	}

//	i_ra = (Rechenarten)int.Parse(Console.ReadLine());			funktioniert auch
	i_ra = Enum.Parse<Rechenarten>(Console.ReadLine());

	switch (i_ra)
	{
		case Rechenarten.Addition:
			Console.WriteLine($"Ergebnis {i_ra}:" + (z1 + z2));
			break;

		case Rechenarten.Subtraktion:
			Console.WriteLine("Ergebnis Subtraktion:" + (z1 - z2));
			break;

		case Rechenarten.Multiplikation:
			Console.WriteLine("Ergebnis Multiplikation:" + (z1 * z2));
			break;

		case Rechenarten.Division:
			if (z2 != 0)
				Console.WriteLine("Ergebnis Division:" + (z1 / z2));
			else
				Console.WriteLine("FEHLER: Division durch 0 nicht erlaubt");
			break;

		default:
			Console.WriteLine("FEHLER: Rechenart falsch eingegeben");
			break;

	}

	Console.WriteLine("\n");
	Console.WriteLine("Weiter machen (Y)?");
}
while (Console.ReadKey().Key == ConsoleKey.Y);

#endregion





	// !!!! WICHTIG !!!!    Enums müssen immer am Ende der Datei definiert werden
enum Wochentag { MO = 1, DI = 2, MI = 3, DO = 4, FR = 5, SA = 6, SO = 7};
enum Rechenarten 
{
	Addition =1,
	Subtraktion,
	Multiplikation,
	Division
};

