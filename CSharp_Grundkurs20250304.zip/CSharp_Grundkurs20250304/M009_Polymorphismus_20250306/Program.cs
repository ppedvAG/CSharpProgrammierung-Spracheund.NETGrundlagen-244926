﻿namespace M009_Polymorphismus_20250306;
	internal class Program
	{
		static void Main(string[] args)
		{
		// Basisklasse     Unterklasse
		Lebewesen lw = new Mensch(30, "Max");
		lw.Bewegen(50);

		//		Mensch m = new Lebewesen(50);				falsche Richtung, dies geht nicht da Lebewese die Basisklasse ist

		//		Lebewesen 

		if (lw.GetType() == typeof(Mensch))
		{
			Console.WriteLine("Lebewesen ist Typ Mensch");
		}

		if (lw.GetType() == typeof(Lebewesen))
		{
			Console.WriteLine("Lebewesen ist Typ Lebewesen");
		}



		Lebewesen lebewesen = new Lebewesen(50);
		Mensch mensch = new Mensch(30, "Peter");

		if (lebewesen is Lebewesen)
            Console.WriteLine("TRUE");
		if (lebewesen is Mensch)
			Console.WriteLine("TRUE");
		if (mensch is Lebewesen)
			Console.WriteLine("TRUE");
		if (mensch is Mensch)
			Console.WriteLine("TRUE");
		if (mensch is Object)
			Console.WriteLine("TRUE");


	}
}
