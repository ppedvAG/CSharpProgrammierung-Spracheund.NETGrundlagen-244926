﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M009_Polymorphismus_20250306
{
	public class Mensch : Lebewesen
	{
		public Mensch(int alter ,string name) : base(alter)
		{
			Name = name;	
		}

		public string Name { get; set; }

		public override void Bewegen(int distanz)
		{
            Console.WriteLine($"{Name} bewegt sich um {distanz}m.");
		}
	}
}
