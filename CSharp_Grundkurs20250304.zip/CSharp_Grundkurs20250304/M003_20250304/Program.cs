﻿#region Arrays
using System.ComponentModel.Design;

int[] arInt = new int[10]; // 10 Elemente, Index 0-9
arInt[0] = 1;

Console.WriteLine(arInt[0]);

Console.WriteLine(arInt);		// gibt Typinformation aus


arInt = new int[] {1, 2, 3, 4, 5, 6};   // Überschreibt arInt, macht Werte-Initialisierung


int[] zahlen2 = { 11, 22, 33 };

int[] zahlen3 = [ 11, 22, 33 ];		// ab .Net 8.0



int[,] zweiDimensionen = new int[,] {{ 11, 22, 33}, { 1, 2, 3 } };
int[,] zweiDimensionen2 = { { 11, 22, 33 }, { 1, 2, 3 } };

int[,] zweiDimensionen3;
zweiDimensionen3 = new int[,] { { 11, 22, 33 }, { 1, 2, 3 } };


Console.WriteLine(zweiDimensionen[0, 1]);
Console.WriteLine(zweiDimensionen[0, 2]);
Console.WriteLine(zweiDimensionen[1, 2]);

#endregion

#region Bedingungen

if (true)
{ }
else if (false)
{ }
else
{ }


//	==, != gleich/ungleich
//	< > <= >=


string hallo = "Hallo";
string welt = "Welt";

if (hallo.Length > welt.Length) { }



// logische Vergleiche
//	&&	Und
//	||	Oder
//	!	Nicht
//	^	Exklusiv-Oder XOR

int z1 = 5;
int z2 = 8;
int z3 = 12;


z1 = int.Parse(Console.ReadLine());


if (z1 > z2 && z1 > z3) 
{ Console.WriteLine("z1 größer z2 UND größer z3"); }

if (z1 > z2 || z1 > z3)
{ Console.WriteLine("z1 größer z2 ODER größer z3"); }


// Ternary Operator
// => wenn die Ausgabe nur einen Befehl hat

//			Bedingung ? TRUE-Wert	:	FALSE-Wert	;
string x = (z1 > z2) ? "z1 größer z2" : "z1 kleiner / gleich z2";


#endregion


#region Schaltjahr
Console.WriteLine("Jahr eingeben");
int jahr = int.Parse(Console.ReadLine());

if (jahr % 4 == 0)
{
	if (jahr % 100 == 0)
	{
		if (jahr % 400 == 0)
		{ Console.WriteLine("Schaltjahr"); }

		else
		{ Console.WriteLine("kein Schaltjahr"); }
	}
	else
		{ Console.WriteLine("Schaltjahr"); }
}
else { Console.WriteLine("Kein Schaltjahr"); }
#endregion


#region Array Contains
int[] arLotto = new int[] { 1, 2, 3, 4, 5, 6 };   // Überschreibt arInt, macht Werte-Initialisierung

Console.WriteLine("Gebe eine Lotto-Zahl von 1 bis 99 ein:");
int input = int.Parse(Console.ReadLine());

if (arLotto.Contains(input))
{ Console.WriteLine("Treffer"); }
else
{ Console.WriteLine("kein Treffer"); }


#endregion


#region Zahl als TRUE/FALSE

Console.WriteLine("Gebe eine Zahl ein:");
int inputTrue = int.Parse(Console.ReadLine());

//if (bool.Parse(inputTrue))					funktioniert nicht

if (!Convert.ToBoolean(inputTrue))
{ Console.WriteLine("FALSE"); }
else
{ Console.WriteLine("TRUE"); }

#endregion


