﻿namespace M006_Fahrzeug_20250305.Data
{
	public class Fahrzeug
	{
		public string Name { get; set; }			// get/set muss nicht unbedingt programmiert werden
		private int VMax;
		private int VAct;
		private double Preis;
		private bool MotorLauft;

		public virtual string Info()
		{
			string InfoTxt;

			InfoTxt = "Fahrzeugname: " + this.Name + "; Vmax = " + this.VMax + "; Vact: " + this.VAct + "; Preis: " + this.Preis + "; Motor läuft: " + this.MotorLauft;

//			Console.WriteLine(InfoTxt + "\n\n");
			return InfoTxt;
		}

		public bool StarteMotor()
		{
			bool erfolgreich = false;
			if (!MotorLauft) 
			{
				MotorLauft = true;
				erfolgreich = true;			// starten war erfolgreich
			}
			return erfolgreich;
		}

		public bool StoppeMotor()
		{
			bool erfolgreich = false;
			if (MotorLauft && VAct == 0)
			{
				MotorLauft = false;
				erfolgreich = true;            // stoppen war erfolgreich
			}
			return erfolgreich;
		}

		public bool Beschleunige(int a)
		{
			bool erfolgreich = false;

			if (MotorLauft)
			{
				VAct += a;
				if (VAct <= 0)
				{ VAct = 0; }
				else if (VAct > VMax)
				{ VAct = VMax; }
				else { erfolgreich = true; }
			}
			return erfolgreich;
		}

		public Fahrzeug(string name, int vMax, double preis)
		{
			Name = name;
			VMax = vMax;
			VAct = 0;
			Preis = preis;
			MotorLauft = false;
		}

	}
}
