﻿using M006_Fahrzeug_20250305.Data;
using M006_Fahrzeug_20250305.mehrFahrzeuge;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Runtime.InteropServices;
namespace M006_Fahrzeug_20250305;


internal class Program
{
	static void Main(string[] args)
	{
		#region Variablen
		ConsoleKeyInfo taste;
		#endregion



		Console.WriteLine("Hallo Fahrzeugwelt \n\n");


		Fahrzeug BMW = new Fahrzeug("320i", 230, 45000.01);
		Fahrzeug Audi = new Fahrzeug("A5", 250, 75000.01);

		Console.WriteLine(Audi.Info()+ "\n");
		Console.WriteLine(BMW.Info() + "\n");


		bool weiter = true;
		do
		{

			Console.WriteLine("Was willst Du tun?");
			Console.WriteLine("Starte Motor:  1");
			Console.WriteLine("Stoppe Motor:  2");
			Console.WriteLine("Beschleunigen: 3");

			taste = Console.ReadKey();
			Console.WriteLine("\n");


			//			 taste.Key = ConsoleKey.Y


			switch (taste.Key)
			{
				case ConsoleKey.NumPad1:
					if (Audi.StarteMotor())
						Console.WriteLine("Motor gestartet!\n");
					else
                        Console.WriteLine("FEHLER!\n");
					break;

				case ConsoleKey.NumPad2:
					if (Audi.StoppeMotor())
						Console.WriteLine("Motor gestoppt!\n");
					else
						Console.WriteLine("FEHLER!\n");
					break;

				case ConsoleKey.NumPad3:
					int a;

                    Console.WriteLine("Gebe die Geschwindigkeitsänderung ein:");
					bool ergebnis = int.TryParse(Console.ReadLine(), out a);

					if (ergebnis && Audi.Beschleunige(a))
						Console.WriteLine("Geschwindigkeit geändert\n");
					else
						Console.WriteLine("FEHLER!\n");
					break;


				default:
					weiter = false;
					break;
			}


			Console.WriteLine(Audi.Info() + "\n");


		} while (weiter);


		PKW Ford = new PKW("Cmax", 200, 35000.01, 5);
		Console.WriteLine(Ford.Info() + "\n");

		Schiff Kutter = new Schiff("alte Scholle", 50, 800000.01, 2.5);
		Console.WriteLine(Kutter.Info() + "\n");

		Flugzeug A530 = new Flugzeug("A530", 500, 25000000.01, 12000);
		Console.WriteLine(A530.Info() + "\n");


		#region Interface-Nutzung

		Container Seecontainer = new Container();

		IBeladbar[] beladbar = [Kutter, Seecontainer];

		int i = 0;

		beladbar[i].Entlade();
		if (i == 0)
			Console.WriteLine(Kutter.Info() + "\n");

		beladbar[i].Belade(Audi);
		if (i == 0)
			Console.WriteLine(Kutter.Info() + "\n");

		beladbar[i].Belade(BMW);
		if (i == 0)
			Console.WriteLine(Kutter.Info() + "\n");

		beladbar[i].Entlade();
		if (i == 0)
			Console.WriteLine(Kutter.Info() + "\n");

		beladbar[i].Entlade();
		if (i == 0)
			Console.WriteLine(Kutter.Info() + "\n");

		#endregion

		#region Stack und Queue
		// Stack
		Stack<string> stacking = new Stack<string>();
		stacking.Push("Element 1"); // Element eintragen
		stacking.Peek(); // oberstes ausgeben
		stacking.Pop(); // oberstes ausgeben & löschen

		Queue<string> queue = new Queue<string>();
		queue.Enqueue("A"); // Element hinzufügen
		queue.Peek(); // ältestes Element ausgeben
		queue.Dequeue(); // ältestes Element ausgeben & löschen


		Queue <Schiff> TransportmittelQueue = new Queue<Schiff>();
		Stack<Fahrzeug> FrachtStack = new Stack<Fahrzeug>();

		// Transportmittel bereitstellen
		Schiff Kutter01 = new Schiff("alte Scholle 01", 50, 800000.01, 2.5);
		Schiff Kutter02 = new Schiff("alte Scholle 02", 50, 800000.01, 2.5);
		Schiff Kutter03 = new Schiff("alte Scholle 03", 50, 800000.01, 2.5);
		Schiff Kutter04 = new Schiff("alte Scholle 04", 50, 800000.01, 2.5);
		Schiff Kutter05 = new Schiff("alte Scholle 05", 50, 800000.01, 2.5);
		Schiff Kutter06 = new Schiff("alte Scholle 06", 50, 800000.01, 2.5);
		Schiff Kutter07 = new Schiff("alte Scholle 07", 50, 800000.01, 2.5);
		Schiff Kutter08 = new Schiff("alte Scholle 08", 50, 800000.01, 2.5);
		Schiff Kutter09 = new Schiff("alte Scholle 09", 50, 800000.01, 2.5);
		Schiff Kutter10 = new Schiff("alte Scholle 10", 50, 800000.01, 2.5);

		TransportmittelQueue.Enqueue(Kutter01);
		TransportmittelQueue.Enqueue(Kutter02);
		TransportmittelQueue.Enqueue(Kutter03);
		TransportmittelQueue.Enqueue(Kutter04);
		TransportmittelQueue.Enqueue(Kutter05);
		TransportmittelQueue.Enqueue(Kutter06);
		TransportmittelQueue.Enqueue(Kutter07);
		TransportmittelQueue.Enqueue(Kutter08);
		TransportmittelQueue.Enqueue(Kutter09);
		TransportmittelQueue.Enqueue(Kutter10);

		// Fracht bereitstellen
		PKW Pkw01 = new PKW("Cmax", 200, 35000.01, 5);
		PKW Pkw02 = new PKW("A3", 200, 35000.01, 5);
		PKW Pkw03 = new PKW("320i", 200, 35000.01, 5);
		PKW Pkw04 = new PKW("320d", 200, 35000.01, 5);
		PKW Pkw05 = new PKW("A6", 200, 35000.01, 5);
		PKW Pkw06 = new PKW("Lupo", 200, 35000.01, 5);
		PKW Pkw07 = new PKW("Golf V", 200, 35000.01, 5);
		PKW Pkw08 = new PKW("A5", 200, 35000.01, 5);
		PKW Pkw09 = new PKW("Clio", 200, 35000.01, 5);
		PKW Pkw10 = new PKW("Ente", 200, 35000.01, 5);

		FrachtStack.Push(Pkw01);
		FrachtStack.Push(Pkw02);
		FrachtStack.Push(Pkw03);
		FrachtStack.Push(Pkw04);
		FrachtStack.Push(Pkw05);
		FrachtStack.Push(Pkw06);
		FrachtStack.Push(Pkw07);
		FrachtStack.Push(Pkw08);
		FrachtStack.Push(Pkw09);
		FrachtStack.Push(Pkw10);

		// Laden
		Dictionary<string, string> Ladeliste = new Dictionary<string, string>();
		Dictionary<Schiff, Fahrzeug> LadelisteFahrzeug = new Dictionary<Schiff, Fahrzeug>();

		while (TransportmittelQueue.Count != 0 && FrachtStack.Count != 0)
		{
			Schiff tempTM = TransportmittelQueue.Dequeue();
			tempTM.Belade(FrachtStack.Pop());
			Ladeliste.Add(tempTM.Name, tempTM.GeladenesFahrzeug.Name);
			LadelisteFahrzeug.Add(tempTM, tempTM.GeladenesFahrzeug);
		}

		// Ladeliste ausgeben
		foreach (KeyValuePair<Schiff, Fahrzeug> kvp in LadelisteFahrzeug)
		{
            Console.WriteLine($"{kvp.Key.Name} hat geladen {kvp.Value.Name} ");
		}
		#endregion


	}
}


public interface IBeladbar
{
	Fahrzeug GeladenesFahrzeug {  get; set; }
	void Belade(Fahrzeug fahrzeug);
	Fahrzeug Entlade();

}


public class Container : IBeladbar
{

	public Fahrzeug GeladenesFahrzeug { get; set; }
	public void Belade(Fahrzeug fahrzeug)
	{
		if (fahrzeug == null)
			Console.WriteLine("Es kann kein Fahrzeug geladen werden: Kein Fahrzeug übergeben!");
		else if (GeladenesFahrzeug != null)
			Console.WriteLine("Es kann kein Fahrzeug geladen werden: Es ist bereits ein Fahrzeug geladen!");
		else
		{
			GeladenesFahrzeug = fahrzeug;
			Console.WriteLine($"Das Fahrzeug {GeladenesFahrzeug.Name} ist geladen.");
		}
	}
	public Fahrzeug Entlade()
	{
		if (GeladenesFahrzeug == null)
		{
			Console.WriteLine("Entladen nicht möglich da nichts geladen!");
			return null;
		}
		else
		{
			Fahrzeug fahrzeug = GeladenesFahrzeug;
			Console.WriteLine($"Das Fahrzeug {fahrzeug.Name} ist entladen.");
			GeladenesFahrzeug = null;
			return fahrzeug;
		}
	}
	public Container()
	{
	}

}
