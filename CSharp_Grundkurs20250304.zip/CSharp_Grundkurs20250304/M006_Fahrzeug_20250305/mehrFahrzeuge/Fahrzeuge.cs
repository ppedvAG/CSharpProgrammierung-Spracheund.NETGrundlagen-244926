﻿using M006_Fahrzeug_20250305.Data;

namespace M006_Fahrzeug_20250305.mehrFahrzeuge
{
	internal class PKW : Fahrzeug
	{
		internal double Sitzplaetze;

		public override string Info()
		{
			string InfoTxt = base.Info();

			InfoTxt += "\n Der PKW hat " + this.Sitzplaetze + " Sitzplätze.";

			return InfoTxt;
		}

		public PKW(string name, int vMax, double preis, double sitzplaetze) : base(name, vMax, preis)
		{
			this.Sitzplaetze = sitzplaetze;
		}
	}
	internal class Schiff : Fahrzeug, IBeladbar
	{
		internal double Tiefgang;

		public override string Info()
		{
			string InfoTxt = base.Info();

			InfoTxt += "\n Das Schiff hat einen Tiefgang von " + this.Tiefgang + "m.";

			if (GeladenesFahrzeug == null)
				InfoTxt += "\n Es ist kein Fahrzeug geladen.";
			else if (GeladenesFahrzeug != null)
				InfoTxt += $"\n Es ist das Fahrzeug {GeladenesFahrzeug.Name} geladen.";

			return InfoTxt;
		}

		#region Interface
		public Fahrzeug GeladenesFahrzeug { get; set; }
		public void Belade(Fahrzeug fahrzeug)
		{
			if (fahrzeug == null)
				Console.WriteLine("Es kann kein Fahrzeug geladen werden: Kein Fahrzeug übergeben!");
			else if (GeladenesFahrzeug != null)
				Console.WriteLine("Es kann kein Fahrzeug geladen werden: Es ist bereits ein Fahrzeug geladen!");
			else
			{
				GeladenesFahrzeug = fahrzeug;
				Console.WriteLine($"Das Fahrzeug {GeladenesFahrzeug.Name} ist geladen.");
			}
		}
		public Fahrzeug Entlade()
		{
			if (GeladenesFahrzeug == null)
			{ 
				Console.WriteLine("Entladen nicht möglich da nichts geladen!");
				return null;
			}
			else
			{
				Fahrzeug fahrzeug = GeladenesFahrzeug;
				Console.WriteLine($"Das Fahrzeug {fahrzeug.Name} ist entladen.");
				GeladenesFahrzeug = null;
				return fahrzeug;
			}
		}

		#endregion
		#region Konstruktor
		public Schiff(string name, int vMax, double preis, double tiefgang) : base(name, vMax, preis)
		{
			this.Tiefgang = tiefgang;
		}
		#endregion
	}


	internal class Flugzeug : Fahrzeug
	{
		internal double Flughoehe;
		public override string Info()
		{
			string InfoTxt = base.Info();

			InfoTxt += "\n Das Flugzeug kann " + this.Flughoehe + "m hoch fliegen.";

			return InfoTxt;
		}

		public Flugzeug(string name, int vMax, double preis, double flughoehe) : base(name, vMax, preis)
		{
			this.Flughoehe = flughoehe;
		}
	}
}




