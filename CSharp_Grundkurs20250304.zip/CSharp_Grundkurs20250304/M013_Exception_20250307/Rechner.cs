﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M013_Exception_20250307;

public class Rechner
{
	public double Addieren(double x, double y)
	{ return x + y; }

	public double Subtrahieren(double x, double y)
		{ return x - y; }
}
