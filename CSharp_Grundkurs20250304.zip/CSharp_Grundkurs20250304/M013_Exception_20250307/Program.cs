﻿namespace M013_Exception_20250307;
internal class Program
{
	static void Main(string[] args)
	{

		try
		{

			string eingabe = Console.ReadLine();
			int x = int.Parse(eingabe);

		}
		catch (FormatException ex)
		{

			Console.WriteLine("Die Eingabe ist keine Zahl");
			Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
			Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
		}
		catch (OverflowException ex)
		{
			Console.WriteLine("Die Eingabe ist zu groß/klein");
			Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
			Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
		}
		catch (Exception ex)
		{
			Console.WriteLine("Sonstige Fehler aufgetreten");
			Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
			Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
		}
		finally     // wird immer ausgeführt
		{
			Console.WriteLine("Parsen fertig");
		}


		///		if(
		///						try
		///						{
		///
		///							string eingabe = Console.ReadLine();
		///							int x = int.Parse(eingabe);
		///
		///						}
		///						catch (Exception)
		///						{
		///							Console.WriteLine("Sonstige Fehler aufgetreten");
		///							Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
		///							Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
		///						}
		///						)
		///		{ Console.WriteLine("Fehlerfrei durchlaufen :-)"); }



		bool keinFehler = true;
		try
		{

			string eingabe = Console.ReadLine();
			int x = int.Parse(eingabe);
			Console.WriteLine("Fehlerfrei durchlaufen :-) - 1");				// Code wird nur ausgeführt wenn alles vorher fehlerfrei war

		}
		catch (Exception ex)
		{
			keinFehler = false;
			Console.WriteLine("Sonstige Fehler aufgetreten");
			Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
			Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
		}
		
		
		
		if(!keinFehler)
			Console.WriteLine("Fehlerfrei durchlaufen :-) -2");
















	}
}