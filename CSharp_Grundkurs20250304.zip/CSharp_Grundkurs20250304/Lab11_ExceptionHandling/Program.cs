﻿using System;

namespace Lab11_ExcpetionHandling
{
	public enum Rechenoperation { Addition = 1, Subtraktion, Multiplikation, Division }

	class Program
	{
		//F�ge in die Main()-Methode eine Try/Catch-Mechanik ein, welche mindestens vier verschiedene Exceptions abf�ngt und dem Benutzer eine
		//sinnvolle Fehlermeldung ausgibt. Etabliere zudem eine Mechanik, welche das Programm im Fehlerfall wiederholt.
		static void Main(string[] args)
		{
			////			string eingabe = GetEingabe();
			////
			////			Term term = new Term(eingabe);
			////
			////			int ergebnis = BerechneTerm(term);
			////
			////			Console.WriteLine($"\t={ergebnis}");


			string eingabe = GetEingabe();
			Term term = new Term();
			try
			{
				term.InputAuswerten(eingabe);

				int ergebnis = BerechneTerm(term);

				Console.WriteLine($"\t={ergebnis}");
			}
			catch (FormatException ex)
			{

				Console.WriteLine("Die Eingabe ist keine Zahl");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}
			catch (OverflowException ex)
			{
				Console.WriteLine("Die Eingabe ist zu groß/klein");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}
			catch (DivideByZeroException ex)
			{
				Console.WriteLine("Division durch 0 ist nicht erlaubt");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}

			catch (NullReferenceException ex)				// Exception braucht nicht abgefangen werden, da diese immer einen Systemabsturz verursacht!!!!!!!
			{
				Console.WriteLine("null");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}

			catch (Exception ex)
			{
				Console.WriteLine("Sonstige Fehler aufgetreten");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}
		}

		//Code�nderungen sollen nur in der Main()-Methode stattfinden.
		static string GetEingabe()
		{
			Console.WriteLine("Bitte gib einen Term mit zwei Zahlen und einem Grundrechenoperator (+ - * /) ein (z.B.: 25+13):");
			return Console.ReadLine();
		}

		static int BerechneTerm(Term term)
		{
			switch (term.Operation)
			{
				case Rechenoperation.Addition:
					return term.Zahl1 + term.Zahl2;
				case Rechenoperation.Subtraktion:
					return term.Zahl1 - term.Zahl2;
				case Rechenoperation.Multiplikation:
					return term.Zahl1 * term.Zahl2;
				default:
					return term.Zahl1 / term.Zahl2;
			}
		}
	}

	class Term
	{
		public string Eingabe { get; set; }
		public int Zahl1 { get; set; }
		public int Zahl2 { get; set; }
		public Rechenoperation Operation { get; set; }

		public Term() { }

//		public Term(string term)
//		{
//			this.Eingabe = term;
//			this.Operation = this.GetRechenoperation();
//
//			string[] zahlen = this.SplitTerm();
//
//			this.Zahl1 = int.Parse(zahlen[0]);
//			this.Zahl2 = int.Parse(zahlen[1]);
//		}

		public void InputAuswerten(string term)
		{

			this.Eingabe = term;
			this.Operation = this.GetRechenoperation();

			string[] zahlen = this.SplitTerm();




			try
			{
				if (zahlen == null)
										throw new NullReferenceException("zahlen == null");		//	!!!!!!!!!!!!!!   NullReferenceException ist immer ein Systemabsturz, dieser verursacht immer einen Systemabsturz
					throw new ArgumentNullException("zahlen == null");

				this.Zahl1 = int.Parse(zahlen[0]);				// !!!!!!!!!!!!!!			Try funktioniert in diesem Fall nicht!!!!
			}
			catch (NullReferenceException ex)
			{
				Console.WriteLine("null");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist

				this.Zahl1 = 1;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Sonstige Fehler aufgetreten");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}

			try
			{
				if (zahlen == null)
					throw new ArgumentNullException("zahlen == null");

				this.Zahl2 = int.Parse(zahlen[1]);
			}
			catch (NullReferenceException ex)
			{
				Console.WriteLine("null");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist

				this.Zahl2 = 1;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Sonstige Fehler aufgetreten");
				Console.WriteLine(ex.Message);          // die C# interne Fehlermeldung
				Console.WriteLine(ex.StackTrace);       // Rückverfolgung wo der Fehler passiert ist
			}

		}

		private Rechenoperation GetRechenoperation()
		{
			if (this.Eingabe.Contains('+'))
				return Rechenoperation.Addition;
			else if (this.Eingabe.Contains('-'))
				return Rechenoperation.Subtraktion;
			else if (this.Eingabe.Contains('*'))
				return Rechenoperation.Multiplikation;
			else if (this.Eingabe.Contains('/'))
				return Rechenoperation.Division;
			else
				return 0;
		}

		private string[] SplitTerm()
		{
			switch (this.Operation)
			{
				case Rechenoperation.Addition:
					return this.Eingabe.Split('+');
				case Rechenoperation.Subtraktion:
					return this.Eingabe.Split('-');
				case Rechenoperation.Multiplikation:
					return this.Eingabe.Split('*');
				case Rechenoperation.Division:
					return this.Eingabe.Split('/');
			}
			return null;
		}
	}
}