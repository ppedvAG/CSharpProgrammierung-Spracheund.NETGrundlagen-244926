﻿
namespace M006_OOP_Klassen_Objekte_20250305.Data
{
	public enum Schulungstyp
	{
		Praesenz,
		Virtuell,
		Hybrid,
		Inhouse
	}
}
