﻿using System;									// ausgegraut bedeudet dass dies schon eingebunden ist
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M006_OOP_Klassen_Objekte_20250305.Data;



public class Person
{
	#region Feld
	private string vorname;				// private => nur innerhalb der Klasse aufrufbar
	private double gewicht;
	public int alter { get; set; }

	public string GetVorname()
	{ 
		return this.vorname; 
	}

	public void SetVorname(string vorname)
	{
		this.vorname = vorname;
	}
	#endregion

	#region Eigenschaft
	// vereinfachung von Get Set
	private string name { get; set; }

	// full property
	public string nachname
	{
		get
		{
			return this.name;
		}
		set
		{
			this.name = value;
		}
	}
	#endregion


	#region Konstruktor
	public Person()
	{
		Console.WriteLine("Person erstellt");
	}

	// alternativer Konstruktor
	public Person(string vorname, string nachname) : this() // this() bezieht sich auf Person => wenn dieser Aufruf nicht verwendet wird, wird alertnativ this() verwendet
	{
		Console.WriteLine("Person initialisier");
		this.vorname = vorname;
		this.name = nachname;
	}


	// Verkettung von Konstruktoren
	public Person(string vorname, string nachname, int alter) : this( vorname,  nachname)	// => this bezieht sich auf den weiteren aufzurufenden Konstruktor
	{
		this.alter = alter;
	}







	#endregion









}

