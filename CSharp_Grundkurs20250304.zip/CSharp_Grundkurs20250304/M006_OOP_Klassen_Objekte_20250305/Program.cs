﻿using M006_OOP_Klassen_Objekte_20250305.Data;
namespace M006_OOP_Klassen_Objekte_20250305;

internal class Program
{
	static void Main(string[] args)
	{
		// Objekt erstellen
		Person p1 = new Person();
		Person p2 = new Person();
		Person p3 = new Person();

		p1.SetVorname("Max");
		p1.nachname = "Mustermann";
		p1.alter = 25;

		p2.SetVorname("Udo");
		p2.nachname = "Mustermann";
		p2.alter = 30;

		p3.SetVorname("Gerda");
		p3.nachname = "Musterfrau";
		p3.alter = 30;



		Console.WriteLine($"{p1.GetVorname() + p1.nachname} ist {p1.alter}");


		Schulung s = new Schulung(p1, "Burghausen", Schulungstyp.Praesenz, 4, "C# Grundkurs", p2);

		s.NeueTeilnehmerHinzufügen(new Person());
		s.NeueTeilnehmerHinzufügen(p3);


		Console.WriteLine($"Der Trainer: {s.Trainer.GetVorname()} {s.Trainer.nachname}, der Ort: {s.Standort}, die Teilnehmer: {s.Teilnehmer[0].GetVorname()}");

	
		foreach (Person teilnehmer in s.Teilnehmer)
		{
			Console.WriteLine(teilnehmer.nachname);
			

		}


/*

		foreach

	foreach (var i in Enum.GetValues<Rechenoperation>())        // hier wird jedes Enum-Element ausgegeben
			{
				Console.WriteLine($"{(int)i}: {i}");
			}





*/

	}
}





