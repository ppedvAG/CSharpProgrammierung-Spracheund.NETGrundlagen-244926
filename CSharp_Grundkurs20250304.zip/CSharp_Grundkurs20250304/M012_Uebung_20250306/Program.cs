﻿using System.Diagnostics;                       // Wird nun benötigt!
using System.Text.Json;

namespace M012_Linq_Lamba_Uebung;

internal class Program
{
	static void Main(string[] args)
	{
		#region File lesen
		string readJson = File.ReadAllText(@"..\..\..\Personen.json");
		List<Person> personen = JsonSerializer.Deserialize<List<Person>>(readJson)!;
		#endregion

		//Übungsaufgaben
		personen.Where(e => e.Alter >= 60);

		personen.Where(e => e.Job.Gehalt >= 5000);
		

		//									!!! zweite Sortierung ThenBy
		personen.OrderBy(e => e.Job.Titel).ThenBy(e => e.Job.Gehalt);

		personen.Count(e => e.Vorname.Length > 10);

		personen.Average(e => e.Job.Gehalt);
//		personen.Select(e => e.Job.Titel == "Softwareentwickler").Average(e => e.Job.Gehalt);     geht mit SELECT nicht
		personen.Where(e => e.Job.Titel == "Softwareentwickler").Average(e => e.Job.Gehalt);

//		personen.Count(e => e.Hobbies.Capacity()      .Count() = 2);
//		personen.Count(static e => e.Hobbies[1] != "" && e.Hobbies[2]. is == "");
		personen.Count(e => e.Hobbies.Count == 2);

		personen.Where(e => e.Alter > 50).All(e => e.Job.Gehalt * 12 >= 25000);

		personen.Where(e => e.Hobbies.Contains("Radfahren") && e.Hobbies.Contains("Laufen"));

		personen.Where(e => e.Vorname.StartsWith('M') && e.Nachname.StartsWith('S'));

		personen.Where(e => e.Vorname[0] == e.Nachname[0]);

		double alterDurchschn = personen.Average(e => e.Alter);
		personen.Where(e => e.Alter >  alterDurchschn);
		// Alternative
				personen.Where(e => e.Alter > personen.Average(e => e.Alter));



	}
}

///////////////////////////////////////////////////////////////////////////////

[DebuggerDisplay("Person - ID: {ID}, Vorname: {Vorname}, Nachname: {Nachname}, GebDat: {Geburtsdatum.ToString(\"yyyy.MM.dd\")}, Alter: {Alter}, " +
	"Jobtitel: {Job.Titel}, Gehalt: {Job.Gehalt}, Einstellungsdatum: {Job.Einstellungsdatum.ToString(\"yyyy.MM.dd\")}")]
public record Person(int ID, string Vorname, string Nachname, DateTime Geburtsdatum, int Alter, Beruf Job, List<string> Hobbies);

public record Beruf(string Titel, int Gehalt, DateTime Einstellungsdatum);

///////////////////////////////////////////////////////////////////////////////

