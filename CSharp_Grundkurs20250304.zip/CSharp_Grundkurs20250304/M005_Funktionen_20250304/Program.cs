﻿internal class Program
{

	private static void Main(string[] args)
	{
		int z = PrintAdd(5, 8);
		Console.WriteLine($"Summe: {z}");

		double x = PrintAdd(5.0, 8.0);
		Console.WriteLine($"Summe: {x}");

		int y = PrintAdd(5, 8, 9);
		Console.WriteLine($"Summe: {y}");

		int ergebnis;

		ergebnis=Addiere(1, 2, 3);
		Console.WriteLine(ergebnis);

		ergebnis = Addiere(1, 2);
		Console.WriteLine(ergebnis);

		int[] zahlen = [2,3,4,5];
		ergebnis = Addiere(zahlen);
		Console.WriteLine(ergebnis);


		Taschenrechner();
	}

#region Funktionen
	// Funktion: zwei Zahlen empfangen, addieren und in der Konsole ausgeben
	static int PrintAdd(int z1, int z2)
	{
		int summe = z1 + z2;
		Console.WriteLine($"{z1} + {z2} = {summe}");
		return summe;
	}

	// Überladungen => 
	static double PrintAdd(double z1, double z2)
	{
		double summe = z1 + z2;
		Console.WriteLine($"{z1} + {z2} = {summe}");
		return summe;
	}

	static int PrintAdd(int z1, int z2, int z3)
	{
		int summe = z1 + z2 + z3;
		Console.WriteLine($"{z1} + {z2} + {z3} = {summe}");
		return summe;
	}

	// params			Parameter mit params müssen am Ende hinzugefügt werden, dann können soviele wie jeder Anwender übergeben werden
	static int Addiere(params int[] zahlen)
	{
		return zahlen.Sum();
	}

	// optionale Parameter
	static double Subtrahiere(int a = 0, int b= 0, int c= 0)
	{
		return a + b + c;
	}
	#endregion

	#region Taschenrechner

	static void Taschenrechner()
	{
		do 
		{
		Rechenoperation operation;
		bool fehler;
		Console.WriteLine("\n");
		Console.WriteLine("Taschenrechner");
		Console.WriteLine("\n");
		double z1 = ZahlEingabe("Gib die erste Zahl ein: ");
		double z2 = ZahlEingabe("Gib die zweite Zahl ein: ");

		operation = RechenoperationEingabe();

		Berechne(z1, z2, operation, out fehler);

		Console.WriteLine("\n");


		Console.WriteLine("\n");
		Console.WriteLine("Weiter machen (Y)?");
		}
		while (Console.ReadKey().Key == ConsoleKey.Y);
	}




static double Berechne(double zahl1, double zahl2, Rechenoperation operation, out bool fehler)
	{
		double ergebnis;

		fehler = false;
		switch (operation)
		{
			case Rechenoperation.Addition:
				ergebnis = zahl1 + zahl2;
				Console.WriteLine($"Ergebnis {operation}:" + ergebnis);
				break;

			case Rechenoperation.Subtraktion:
				ergebnis = zahl1 - zahl2;
				Console.WriteLine("Ergebnis Subtraktion:" + ergebnis);
				break;

			case Rechenoperation.Multiplikation:
				ergebnis = zahl1 * zahl2;
				Console.WriteLine("Ergebnis Multiplikation:" + ergebnis);
				break;

			case Rechenoperation.Division:
				if (zahl2 != 0)
				{
					ergebnis = zahl1 / zahl2;
					Console.WriteLine("Ergebnis Division:" + ergebnis);
				}
				else
					{ 
					ergebnis = double.NaN;
					Console.WriteLine("FEHLER: Division durch 0 nicht erlaubt");
					fehler = true;
			}
				break;

			default:
				ergebnis = double.NaN;
				Console.WriteLine("FEHLER: Rechenart falsch eingegeben");
				fehler = true;
				break;

		}
		return ergebnis;
	}

static double ZahlEingabe(string text)
	{
		bool funktioniert;
		double ergebnis;
		do
		{
			Console.WriteLine(text);
			//		return double.Parse(Console.ReadLine());
			funktioniert = double.TryParse(Console.ReadLine(), out ergebnis);
		} while (!funktioniert);
		return ergebnis;
	}

	static Rechenoperation RechenoperationEingabe()
	{
		int x;
		Console.WriteLine("Rechenarten: ");
		foreach (var i in Enum.GetValues<Rechenoperation>())		// hier wird jedes Enum-Element ausgegeben
		{
			Console.WriteLine($"{(int)i}: {i}");
		}

		do
		{
			x = (int)Math.Round(ZahlEingabe("Wähle eine Rechenart aus (1-4): "), 0);

///		} while ( x <=1 || x > (int)Rechenoperation.Division );
	} while (! (x >0 && x <= (int) Rechenoperation.Division ));
		
////		return Enum.Parse<Rechenoperation>(x);			// geht nicht, da wird als Eingang Char benötigt  !! Eigentlich auch String als Eingang möglich, wegen Überladung wurde Char in der Hilfe angegeben
		return (Rechenoperation)x;			// dies parst den Wert von x in das Enum Rechenoperation
	}


	enum Rechenoperation
	{
		Addition = 1,
		Subtraktion,
		Multiplikation,
		Division
	};

	#endregion

}















