﻿using System.Diagnostics;						// Wird nun benötigt!

namespace M012_Linq_Lambda_20250306;
internal class Program
{
	static void Main(string[] args)
	{

		#region Einfachs Linq
		IEnumerable<int> zahlen = Enumerable.Range(0, 1_000_000);			// Unterstriche dienen nur zur optischen Strukturierung, können auch wege gelassen werden

		List<int> ints = Enumerable.Range(1, 200).ToList();

        Console.WriteLine(ints.Average());
		Console.WriteLine(ints.Min());
		Console.WriteLine(ints.Max());
		Console.WriteLine(ints.Sum());

		Console.WriteLine(ints.First());
		Console.WriteLine(ints.Last());


        // Linq Funktion

        Console.WriteLine(ints.FirstOrDefault(e => e %50 == 0));
		#endregion

		#region Linq mit Objekten
		List<Fahrzeug> fahrzeuge = new List<Fahrzeug>()
												{
													new Fahrzeug(250, FahrzeugMarke.Audi),
													new Fahrzeug(240, FahrzeugMarke.BMW),
													new Fahrzeug(230, FahrzeugMarke.Audi),
													new Fahrzeug(220, FahrzeugMarke.Audi),
													new Fahrzeug(210, FahrzeugMarke.BMW),
													new Fahrzeug(200, FahrzeugMarke.Audi),
													new Fahrzeug(190, FahrzeugMarke.VW),
													new Fahrzeug(180, FahrzeugMarke.VW),
													new Fahrzeug(170, FahrzeugMarke.VW),
													new Fahrzeug(160, FahrzeugMarke.VW),
													new Fahrzeug(150, FahrzeugMarke.VW)
												};

		// alle VWs finden
		List<Fahrzeug> vws = fahrzeuge.Where(e => e.Marke == FahrzeugMarke.VW).ToList();

		foreach(var item in vws)
		{
            Console.WriteLine($"VMax: {item.VMax}; Fahrzeugmarke: {item.Marke}");
		}


		// alle VWs finden die min. 220 fahren
		fahrzeuge.Where(e => e.Marke == FahrzeugMarke.VW && e.VMax >= 220);

		fahrzeuge																			// Alternative Möglichkeit
				.Where(e => e.Marke == FahrzeugMarke.VW)
				.Where(e => e.VMax >= 220);


		// alle Fahrzeuge nach Marke sortieren
		fahrzeuge.OrderBy(e => e.Marke);
		fahrzeuge.OrderByDescending(e => e.Marke);

		// sortieren nach mehr Argumenten
		fahrzeuge.OrderBy(e => e.Marke).ThenBy(e => e.VMax);
		fahrzeuge.OrderByDescending(e => e.Marke).ThenByDescending(e => e.VMax);

		// Count() mit Argument
		fahrzeuge.Count(e => e.VMax > 200);


		//				Welche sollen geprüft werden?			entsprechen ALLE diesem Argument? => TRUE/FALSE
		if (fahrzeuge.Where(e => e.Marke == FahrzeugMarke.VW).All(e => e.VMax > 200))
		{ }

		// Any, ist in der Liste einen Inhalt?
		fahrzeuge.Any();



		// welche Marken haben wir
		List<FahrzeugMarke> marken = fahrzeuge.Select(e => e.Marke).ToList();			// füllt Liste mit allen Marken der fahrzeuge-Liste

		foreach(var marke in marken)
            Console.WriteLine($"Diese Marke gibt es: {marke}");

		marken.Distinct().ToList();								// es werden keine Duplikate übergeben

		fahrzeuge.Select(e => e.Marke).Distinct().ToList();     // es werden keine Duplikate übergeben



		// Group By
		fahrzeuge.GroupBy(e => e.Marke);                // gruppiert in einzelne Listen           !! Ergebniss kann durch Debugging angeschaut werden

		///// geht nicht List<Fahrzeug> fahrzeugeGruppiert = fahrzeuge.GroupBy(e => e.Marke).ToList();   
		//		List[]<Fahrzeug> fahrzeugeGruppiert[] = fahrzeuge.GroupBy(e => e.Marke);


		//		source.GroupBy(x => x.Name)
		//	  .ToDictionary(x => x.Key, x => x.Select(e => e.Value).ToList());

////		fahrzeuge.GroupBy(e => e.Marke).ToDictionary(x => x.mar)
////

		// var => wenn Typ nicht bekannt, dann wird Instanz mit dem richtigen Typ angelegt
		var gruppiert = fahrzeuge.GroupBy(e => e.);					// in eine gruppierte Datenstruktur ausgeben		

		foreach(var group in gruppiert)
            Console.WriteLine($"Key: {group.Key}, Gezählt: {group.Count()}");

		#endregion


	}
}

public class Fahrzeug
{
	public int VMax;
	public FahrzeugMarke Marke;

	public Fahrzeug(int vmax, FahrzeugMarke marke)
	{
		Marke = marke;
		VMax = vmax;
	}
}

public enum FahrzeugMarke
{ 
	Audi, VW, BMW
}
