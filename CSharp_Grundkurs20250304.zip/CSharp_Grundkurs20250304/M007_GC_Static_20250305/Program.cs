﻿using System.Runtime.ConstrainedExecution;

namespace M007_GC_Static;

internal class Program
{
	static void Main(string[] args)
	{
		// statische Klasse									vergleichebar mit globalen Funktionen
		int Summe = Mathe.Addiere(5, 9);
		Console.WriteLine(Summe);

		// Null
		Person p1 = null;       // Somit exisitert praktisch für p1 kein Speicher!!


		#region Datum Zeit
		DateTime dt = DateTime.Now;
		DateTime dt2 = new DateTime(2025,03,05,13,29,55);   // Konstruktur

		dt += TimeSpan.FromHours(3);

		Console.WriteLine(dt);

		#endregion
	}
}


class Mathe
{
	public static int Addiere(int a, int b)
	{ return a + b; }
}

class Auto
{
	public static int AnzahlAutos = 0;
	public Auto()
		{
		AnzahlAutos ++;
		}
}

class Person
{
	public string name;
}






