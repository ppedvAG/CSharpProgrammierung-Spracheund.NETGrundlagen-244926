﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace M015_WpfApp_20250307
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}

}
