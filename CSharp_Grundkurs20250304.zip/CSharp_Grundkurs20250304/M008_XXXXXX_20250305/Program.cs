﻿namespace M008_Vererbung;

internal class Program
{
	static void Main(string[] args)
	{
		Mensch m = new Mensch(30, "Max");

		m.Alter = 31;
		m.Bewegen(5);

		Lebewesen tier = new Lebewesen(3);
		tier.Bewegen(10);

	}

}

public class Lebewesen
{
	public int Alter { get; set; }
	
	// eine Methode mit virtual darf überschrieben, ohne virtual kann nicht überschrieben werden
	public virtual void Bewegen(int distanz)
	{
        Console.WriteLine($"Bewegung um {distanz} m");
	}

	public Lebewesen(int alter)		// Konstruktor
	{ 
		this.Alter = alter;
	}
}


public class Mensch : Lebewesen
{
	public string Name { get; set; }

	public override void Bewegen(int distanz)
	{
		//		base.Bewegen(distanz);
		Console.WriteLine($"Bewegung Mensch um {distanz} m");
	}

	public Mensch(int alter,string name) : base(alter)			// konstruktor mit Aufruf base-Konstruktor
	{
		this.Name = name;
	}
}



public class Kind : Mensch
{

	public override void Bewegen(int distanz)	// !!! kann nicht mehr überschrieben werden da Ebene vorher sealed
	{
		//		base.Bewegen(distanz);
		Console.WriteLine($"Bewegung Kind um {distanz} m");
	}

	public Kind(int alter, string name) : base(alter, name)
	{
	}
}