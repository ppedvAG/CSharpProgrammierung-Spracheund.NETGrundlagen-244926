﻿namespace M010_Interfaces;

internal class Program
{
	static void Main(string[] args)
	{
		Smartphone s = new Smartphone();
		Weltkarte w = new Weltkarte();

		IAufladbar[] aufladbars = [s,w];

		aufladbars[0].Maximum = 100;
		aufladbars[0].Aufladen(5);
		aufladbars[0].PrintLadezustand();
		aufladbars[1].Maximum = 100;
		aufladbars[1].Aufladen(5);
		aufladbars[1].PrintLadezustand();

	}
}

public interface IAufladbar
{
	int Ladezustand { get; set; }
	int Maximum {  get; set; }
	void Aufladen(int x);
	void PrintLadezustand();
	double MaxProzent();

}

public class Smartphone : IAufladbar			// es könne aber auch Basisklassen geerbt werden und auch mehr Interfaces, hierfür wird die Basisklasse und die folgenden Interfaces mit KOMMA getrennt aufgeführt
{
	// hier müssen alle Member public gemacht werden
	public int Ladezustand { get; set; }
	public int Maximum { get; set; }
	public void Aufladen(int x)
	{
		Ladezustand += x;
	}
	public void PrintLadezustand()
	{
        Console.WriteLine($"Ladezustand = {Ladezustand}");
	}
	public double MaxProzent()
	{

		return 0;
	}

}

public class Weltkarte : IAufladbar                // hier müssen alle Member public gemacht werden
{
	public int Ladezustand { get; set; }
	public int Maximum { get; set; }
	public void Aufladen(int x)
	{
		Ladezustand += x;
	}
	public void PrintLadezustand()
	{
		Console.WriteLine($"Ladezustand = {Ladezustand}");
	}
	public double MaxProzent()
	{

		return 0;
	}

}

