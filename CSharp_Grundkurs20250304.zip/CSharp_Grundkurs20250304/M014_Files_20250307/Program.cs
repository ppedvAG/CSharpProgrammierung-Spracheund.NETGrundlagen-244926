﻿using Newtonsoft.Json;
using System.Diagnostics;
using System.IO.Compression;
using System.Runtime;
using System.Text.Json;
using System.Xml;
using System.Xml.Serialization;


namespace M014_Files_20250307
{

	class Program
	{
		static void Main(string[] args)
		{
			#region Datei-Handling
			string folderpath = "Test";

			if (!Directory.Exists(folderpath))
			{
				Directory.CreateDirectory(folderpath);
			}

			// Dateipfad erstellen
			string filepath = Path.Combine(folderpath, "Test.txt");             // combine ist plattformunabhängig (\ oder / ist okay)

			// Datei erstellen und beschreiben
			File.WriteAllText(filepath, "Hallo Welt");                          // erstellt Datei und schreibt rein

			File.WriteAllText(filepath, "Tschüß Welt");                         // erstellt Datei und schreibt rein



			//##### Stream #####
			StreamWriter writer = new StreamWriter(filepath);
			writer.WriteLine("Hallo");                  // Füllt Puffer
			writer.WriteLine("Europa");

			writer.Flush();             // Schreibt Puffer in Datei
			writer.Close();             // Schließt die Datei


			StreamReader reader = new StreamReader(filepath);
			List<string> zeilen = new List<string>();

			while (!reader.EndOfStream)
				zeilen.Add(reader.ReadLine());

			reader.Close();

			// using block
			// Am Ende des Blocks wird der Stream automatisch geschlossen			

			using (StreamWriter sw = new StreamWriter(filepath))
			{
				sw.WriteLine("1");
				sw.WriteLine("2");
			}               // hier wird dann die benutzte Datei (using) automatisch geschlossen

			using StreamWriter sw2 = new StreamWriter(filepath);            // funktioniert wie using darüber, Datei wird aber erst am Ende der MEthode geschlossen
			sw2.WriteLine("1");
			sw2.WriteLine("2");
			#endregion


			#region JSON & XML
			// JSON
			// In C# gibt es zwei Möglichkeiten
			// System.Text.JSON
			// Newtonsoft.JSON

			List<Fahrzeug> fahrzeuge = new List<Fahrzeug>()
													{
														new Fahrzeug(250, FahrzeugMarke.Audi),
														new Fahrzeug(240, FahrzeugMarke.BMW),
														new Fahrzeug(230, FahrzeugMarke.Audi),
														new Fahrzeug(220, FahrzeugMarke.Audi),
														new Fahrzeug(210, FahrzeugMarke.BMW),
														new Fahrzeug(200, FahrzeugMarke.Audi),
														new Fahrzeug(190, FahrzeugMarke.VW),
														new Fahrzeug(180, FahrzeugMarke.VW),
														new Fahrzeug(170, FahrzeugMarke.VW),
														new Fahrzeug(160, FahrzeugMarke.VW),
														new Fahrzeug(150, FahrzeugMarke.VW),
													};

			string jsonPath = Path.Combine(folderpath, "Test.json");                // Pfad öffnen

			JsonSerializerSettings options = new JsonSerializerSettings();          // Optionen setzen
			options.Formatting = Newtonsoft.Json.Formatting.Indented;

			string json = JsonConvert.SerializeObject(fahrzeuge, options);          // Liste in String wandeln in "JSON"-Schönschreibung
			File.WriteAllText(jsonPath, json);


			string readJson = File.ReadAllText(jsonPath);
			Fahrzeug[] readFhrz = JsonConvert.DeserializeObject<Fahrzeug[]>(readJson);


			//##### XML
			// write
			string xmlPath = Path.Combine(folderpath, "Test.xml");             // Pfad öffnen
			XmlSerializer xml = new XmlSerializer(fahrzeuge.GetType());
			using (StreamWriter xmlWriter = new StreamWriter(xmlPath))
			{
				xml.Serialize(xmlWriter, fahrzeuge);
			}

			// read
			using (StreamReader xmlReader = new StreamReader(xmlPath))
			{
				List<Fahrzeug> readFzg2 = xml.Deserialize<List<Fahrzeug>>(xmlReader);
			}

		











			#endregion
		}
	}
}





public static class XmlExtension
{
	public static T Deserialize<T>(this XmlSerializer xml, TextReader s)
	{
		return (T)xml.Deserialize(s);
	}
}



	[DebuggerDisplay("Marke: {Marke}, MaxV: {MaxV}")]


	public class Fahrzeug
	{

		public int Vmax {  get; set; }
		public FahrzeugMarke Marke { get; set; }

		public Fahrzeug(int vmax, FahrzeugMarke marke)
		{
			this.Vmax = vmax;
			this.Marke = marke;
		}
	public Fahrzeug() { }

	}


public enum FahrzeugMarke
	{ 
		Audi, VW, BMW, Mercedes
	}