﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using M013_Exception_20250307;

namespace M013_Test
{
	[TestClass]
	public class RechnerTests
	{
		[TestInitialize]

		private
		public void StartUp() => r = new Rechner()
		{
		}
	}
}
