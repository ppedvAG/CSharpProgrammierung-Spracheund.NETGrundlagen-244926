﻿////// See https://aka.ms/new-console-template for more information
////Console.WriteLine("Hello, World!");
////




Console.WriteLine("Gebe die Werte für die Berechnung ein!");
Console.WriteLine("Entfernung (m): ");
int entfernung = int.Parse(Console.ReadLine());

Console.WriteLine("Stunden: ");
int stunden = int.Parse(Console.ReadLine());

Console.WriteLine("Minuten: ");
int minuten = int.Parse(Console.ReadLine());

Console.WriteLine("Sekunden: ");
int sekunden = int.Parse(Console.ReadLine());


int gesamtsekunden = ((stunden * 60) + minuten) * 60 + sekunden;


double meterSec = entfernung / (double)gesamtsekunden;
meterSec = Math.Round(meterSec, 2);

double kilometerSec = meterSec * 3.6;
kilometerSec = Math.Round(kilometerSec, 2);

double mileSec = kilometerSec / 1.61;
mileSec = Math.Round(mileSec, 2);

Console.WriteLine("Meter/Sekunde:     " + meterSec);
Console.WriteLine("Kilometer/Stunde:     " + kilometerSec);
Console.WriteLine("Meilen/Stunde:     " + mileSec);

////string txt = (string)/*(int)*/mileSec;
////Console.WriteLine(txt);
