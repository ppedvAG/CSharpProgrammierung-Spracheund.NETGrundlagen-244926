﻿
namespace M013_Test_02;

[TestClass]
public class Lab11
{
	public Rechner r;

	[TestInitialize]
	public void StartUp() => r = new Rechner();


	[TestCleanup]
	public void CleanUp() => r = null;


	/// /////////////////////////////////////////////
	[TestMethod]


}