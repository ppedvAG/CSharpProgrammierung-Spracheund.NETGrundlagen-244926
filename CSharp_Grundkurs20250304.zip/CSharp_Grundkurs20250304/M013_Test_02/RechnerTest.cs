using M013_Exception_20250307;

namespace M013_Test_02;

[TestClass]
public class RechnerTests
{
	public Rechner r;

	[TestInitialize]
	public void StartUp() => r = new Rechner();


	[TestCleanup]
		public void CleanUp() => r = null;


	/// /////////////////////////////////////////////
	[TestMethod]
	[TestCategory("Addiere")]

	public void TestAddiere()
	{
		double ergebnis = r.Addieren(4, 5);
		Assert.AreEqual(9, ergebnis);
	}

	[TestMethod]
	public void TestAddiere2()
	{
		double ergebnis = r.Addieren(4, 5);
		Assert.AreNotEqual(99, ergebnis);
		ergebnis = r.Addieren(4, 95);
		Assert.AreEqual(98, ergebnis);
	}



	[TestMethod]
	[TestCategory("Subtrahiere")]
	public void TestSubtrahiere()
	{
		double ergebnis = r.Subtrahieren(4, 5);
		Assert.AreEqual(-1, ergebnis);
	}
}
