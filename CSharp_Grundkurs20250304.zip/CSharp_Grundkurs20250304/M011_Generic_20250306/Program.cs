﻿using System.Collections.Generic;

namespace M011_Generic_20250306;
internal class Program
{
	static void Main(string[] args)
	{
		// Generischer Datentyp (Generic)
		List<int> list = new List<int>();
		list.Add(1);
		list.Add(2);	
		list.Add(33);
		list.Add(4);
		list.Add(5);

		foreach (int i in list) 
			Console.WriteLine($"Listenelement: {i}.");

		//Index wie bei Arrays (auch bei 0 beginnend)
		Console.WriteLine($"Listenelement: {list[3]}.");


		if (list.Contains(33))										// es gibt verschiedenste Methoden für die Listen, ähnlich wie beim Array
			Console.WriteLine("Enthält den gesuchten Wert");



		// Dictionary Key/Value
		Dictionary<int, string> keyValuePairs = new Dictionary<int, string>();

		//				  Key Value						=> Key muss eindeutig sein
		keyValuePairs.Add(1, "Wien");
		keyValuePairs.Add(2, "Berlin");
		keyValuePairs.Add(3, "Paris");
		if(keyValuePairs.ContainsKey(1))
			Console.WriteLine(keyValuePairs[1]);



		foreach (KeyValuePair<int, string> kvp in keyValuePairs)
				Console.WriteLine($"Key {kvp.Key}: {keyValuePairs[kvp.Key]} (oder auch so: {kvp.Value}).");


		// ! Den Key zum Value kann man wahrscheinlich nicht so einfach finden. Man müsste wohl alle Keys manuell analysieren
		if (keyValuePairs.ContainsValue("Berlin"))
		{
		}








	}
}









