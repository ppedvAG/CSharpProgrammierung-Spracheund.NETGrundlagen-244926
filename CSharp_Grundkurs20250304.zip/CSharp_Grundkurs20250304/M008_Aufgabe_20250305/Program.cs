﻿
namespace Autohaus
{
	internal class Program
	{
		static void Main(string[] args)
		{

			Auto a1 = new Auto("A6", 65000, 5);					// new wird immer bei Instanziierung einer Klassen benötigt
			Auto a2 = new Auto("A1", 25000, 3);
			Motorrad m1 = new Motorrad("CBF900", 15000, false);

			Console.WriteLine(a1.Info());
			Console.WriteLine(a2.Info());
			Console.WriteLine(a2.SuperInfo());
			Console.WriteLine(m1.Info());


			Auto[] autos = new Auto[] { new Auto("A6", 65000, 5), new Auto("A1", 25000, 3) };

			Console.WriteLine(autos[0].SuperInfo());


			//	FUNKTIONIERT AUCH, ABER DANN KEIN FOREACH MÖGLICH
			//Fahrzeug[] Fahrzeuge = new Fahrzeug[5];
			//
			//Fahrzeuge[0] = a1;
			//Fahrzeuge[1] = a2;
			//Fahrzeuge[2] = m1;


			// Hinweis: Arrays für Objekte beinhalten nur Zeiger auf Objekte und nicht die Objektinstanzen.
			//			Jedes Objekt muss mit new instanziiert werden.
			//			Es können verschiedene Ableitungen der basierenden Array-Klasse instanziiert werden.

			Fahrzeug[] Fahrzeuge = new Fahrzeug[] { new Auto("A6", 65000, 5), new Auto("A1", 25000, 3), new Motorrad("CBF900", 15000, false) };

// Boot geht nicht, es muss immer auf Fahrzeuge basieren 			Fahrzeug[] Fahrzeuge = new Fahrzeug[] { new Auto("A6", 65000, 5), new Auto("A1", 25000, 3), new Motorrad("CBF900", 15000, false), new Boot() };

			Console.WriteLine("\nARRAY-Ausgabe\n");

			foreach (Fahrzeug i in Fahrzeuge)
			{
				Console.WriteLine(i.Info());
			}

			

		}
	}

	public class Fahrzeug
	{

		private string Model { get; set; }
		private double Preis { get; set; }
		internal enType Type { get; set; }

		public virtual string Info()
		{
			string txt = $"Das Fahrzeug ist ein {Type} und heißt {Model} und kann für {Preis} gekauft werden.\n";
			//        Console.WriteLine(txt);
			return txt;
		}

		public Fahrzeug(string model, double preis)
		{
			Model = model;
			Preis = preis;
		}
	}

	public class Auto : Fahrzeug
	{

		private int TuerAnz { get; set; }

		public override string Info()
		{
			string txt = base.Info() + $"Das Fahrzeug hat {TuerAnz} Türen.\n";
			return txt;
		}

		public  string SuperInfo()
		{
			string txt = "SUPER!! " + Info();
			return txt;
		}

		public Auto(string model, double preis, int tuerAnz) : base(model, preis)
		{
			TuerAnz = tuerAnz;
			Type = enType.Auto;
		}


	}

	public class Motorrad : Fahrzeug
	{

		private bool HatBeiwagen { get; set; }
		public override string Info()
		{
			string txt;
			if (HatBeiwagen)
				txt = "Das Fahrzeug hat einen Beiwagen.\n";
			else
				txt = "Das Fahrzeug hat keinen Beiwagen.\n";

			txt = base.Info() + txt;
			return txt;
		}

		public Motorrad(string model, double preis, bool hatBeiwagen) : base(model, preis)
		{
			HatBeiwagen = hatBeiwagen;
			Type = enType.Motorrad;
		}


	}



	public class Boot
	{

		public string Info()
		{
			string txt;
			txt = "Boote verkaufen wir nicht.\n";
			return txt;
		}

		public Boot()
		{
		}


	}







	enum enType
	{
		Auto,
		Motorrad,
		Divers
	};
}
